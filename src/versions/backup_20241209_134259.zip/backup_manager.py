from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import os
import logging

from datetime import datetime

logger = logging.getLogger(__name__)

if __name__ != "__main__":
    from src.folder_manager import FolderManager  # src 패키지에서 임포트!
    from src.config import (
        CREDENTIALS_PATH,
        TOKEN_PATH,
        DEFAULT_MIME_TYPE,
        DRIVE_FOLDER_NAME
    )
else:
    from folder_manager import FolderManager
    from config import (
        CREDENTIALS_PATH,
        TOKEN_PATH,
        DEFAULT_MIME_TYPE,
        DRIVE_FOLDER_NAME
    )

class DriveBackupManager:
    """구글 드라이브에 메모리 파일을 백업하는 매니저 클래스"""
    
    def __init__(self, credentials_path=CREDENTIALS_PATH):
        """
        DriveBackupManager 초기화
        
        Args:
            credentials_path (str): Google OAuth credentials.json 파일 경로
        """
        self.SCOPES = ['https://www.googleapis.com/auth/drive.file']
        self.credentials_path = credentials_path
        self.creds = None
        self.drive_service = None  # 서비스 객체 추가
        self.folder_manager = None
        
    def authenticate(self):
        """Google Drive API 인증 처리"""
        if os.path.exists(TOKEN_PATH):
            logger.info("Using existing token")
            self.creds = Credentials.from_authorized_user_file(TOKEN_PATH, self.SCOPES)
        
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                logger.info("Token expired. Refreshing...")
                self.creds.refresh(Request())
            else:
                logger.info("Initial authentication required. Opening browser for authorization...")
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.credentials_path, self.SCOPES)
                self.creds = flow.run_local_server(port=0)
            
            # 토큰 저장
            with open(TOKEN_PATH, 'w') as token:
                token.write(self.creds.to_json())
                logger.info("Token saved successfully")
                
        # Drive 서비스 생성
        self.drive_service = build('drive', 'v3', credentials=self.creds)
                
        # FolderManager 초기화 (drive_service 전달)
        self.folder_manager = FolderManager(self.drive_service)
    
    def backup_memory_file(self, source_path, folder_name=DRIVE_FOLDER_NAME):
        """
        메모리 파일을 구글 드라이브에 백업
        
        Args:
            source_path (str): 백업할 memory.json 파일 경로
            folder_name (str): 구글 드라이브의 대상 폴더 이름
            
        Returns:
            str: 업로드된 파일의 ID
        """
        try:            
            # 폴더 확인/생성
            folder_id = self.folder_manager.get_or_create_folder(folder_name)
            if not folder_id:
                raise Exception(f"'{folder_name}' 폴더 생성이나 찾기 실패ㅠㅠ")
            
            # 기존 파일 백업 처리
            self._backup_existing_file(self.drive_service, folder_id)  # 서비스 객체 전달
            
            # 새 파일 업로드
            return self._upload_new_file(self.drive_service, source_path, folder_id)  # 서비스 객체 전달
            
        except Exception as e:
            raise Exception(f"백업 중에 문제가 생겼어ㅠㅠ: {str(e)}")
    
    def _backup_existing_file(self, service, folder_id):
        """기존 파일이 있다면 날짜 붙여서 백업"""
        results = service.files().list(
            q=f"name='memory.json' and '{folder_id}' in parents",
            spaces='drive'
        ).execute()
        
        if results.get('files'):
            existing_file = results['files'][0]
            backup_name = f"memory_{datetime.now().strftime('%Y%m%d%H%M%S')}.json"
            
            service.files().update(
                fileId=existing_file['id'],
                body={'name': backup_name}
            ).execute()
            
            logger.info(f"Existing file backed up as: {backup_name}")
    
    def _upload_new_file(self, service, source_path, folder_id):
        """새 파일 업로드"""
        file_metadata = {
            'name': 'memory.json',
            'parents': [folder_id]
        }
        
        media = MediaFileUpload(
            source_path,
            mimetype=DEFAULT_MIME_TYPE,
            resumable=True
        )
        
        file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id'
        ).execute()
        
        logger.info("New file uploaded successfully")
        return file.get('id')


if __name__ == "__main__":
    # 테스트용 메인 코드

    from config import MEMORY_SOURCE_PATH
    
    try:
        manager = DriveBackupManager()
        manager.authenticate()
        file_id = manager.backup_memory_file(MEMORY_SOURCE_PATH)
        print(f"성공적으로 처리했어! 파일 ID: {file_id}")
    except Exception as e:
        print(f"에러가 났네ㅠㅠ: {str(e)}")
