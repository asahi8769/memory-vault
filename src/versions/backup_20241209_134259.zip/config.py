from pathlib import Path

# 프로젝트 루트 디렉토리
ROOT_DIR = Path(__file__).parent.parent

# 구글 API 인증 관련 경로들
CREDENTIALS_DIR = ROOT_DIR / 'credentials'
CREDENTIALS_PATH = CREDENTIALS_DIR / 'credentials.json'
TOKEN_PATH = CREDENTIALS_DIR / 'token.json'
FOLDER_CACHE_PATH = CREDENTIALS_DIR / 'folder_cache.json'

# 메모리 파일 경로
MEMORY_SOURCE_PATH = r"C:\Users\asahi\AppData\Roaming\npm\node_modules\@modelcontextprotocol\server-memory\dist\memory.json"

# 구글 드라이브 설정
DRIVE_FOLDER_NAME = 'claude-memory'

# 기타 설정들
DEFAULT_MIME_TYPE = 'application/json'