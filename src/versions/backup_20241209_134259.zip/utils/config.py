class Config:
    def __init__(self):
        self.drive_folder_id = "your-folder-id"  # Google Drive 폴더 ID
        self.backup_paths = [
            "path/to/backup1",
            "path/to/backup2"
        ]
        self.credentials_path = "credentials/credentials.json"
        self.token_path = "credentials/token.json"
        
    def get_drive_folder_id(self):
        return self.drive_folder_id
        
    def get_backup_paths(self):
        return self.backup_paths
        
    def get_credentials_path(self):
        return self.credentials_path
        
    def get_token_path(self):
        return self.token_path