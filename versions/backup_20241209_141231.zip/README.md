# Memory Vault

Anthropic의 Claude AI 어시스턴트의 MCP MEMORY 기능을 통해 생성된 memory.json 파일을 Google Drive에 자동으로 백업하고 관리하는 시스템입니다. 이를 통해 Claude와의 대화 기록과 컨텍스트를 안전하게 보관하고 필요할 때 복원할 수 있습니다.

## 주요 기능

- Google Drive를 이용한 자동 백업
- 기존 파일 자동 백업 (타임스탬프 포함)
- 로깅 시스템을 통한 백업 상태 모니터링
- 프로젝트 전체 로컬 백업 기능

## 시작하기

### 필수 요구사항

- Python 3.x
- Google Cloud Platform 프로젝트 및 API 인증 정보
- Google Drive API 활성화

### 설치

1. 저장소를 클론합니다:
```bash
git clone [repository-url]
cd memory-vault
```

2. 필요한 패키지를 설치합니다:
```bash
pip install -r requirements.txt
```

3. Google Cloud Platform에서 credentials.json 파일을 다운로드하고 프로젝트 루트 디렉토리에 저장합니다.

### 환경 설정

1. `.env` 파일을 생성하고 다음 설정을 추가합니다:
```
GITHUB_TOKEN=your_github_token
PROJECT_NAME=memory-vault
REPO_DESCRIPTION=Google Drive 기반의 메모리 백업 시스템
```

## 사용 방법

### 메모리 파일 백업

```python
from src.backup_manager import DriveBackupManager
from src.config import config

manager = DriveBackupManager(config.CREDENTIALS_PATH)
manager.authenticate()
file_id = manager.backup_memory_file(config.MEMORY_SOURCE_PATH)
```

### 프로젝트 로컬 백업

```python
from src.utils.backup import backup_project

success, result = backup_project()
if success:
    print(f"백업 완료: {result}")
```

## 프로젝트 구조

- `src/`: 소스 코드
  - `backup_manager.py`: Google Drive 백업 관리
  - `folder_manager.py`: Drive 폴더 관리
  - `config.py`: 설정 관리
  - `utils/`: 유틸리티 함수들
    - `backup.py`: 로컬 백업 기능
    - `logger.py`: 로깅 시스템
    - `git_upload.py`: GitHub 업로드 기능

## 라이선스

이 프로젝트는 MIT 라이선스를 따릅니다.
