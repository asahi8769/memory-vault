from src.backup_manager import DriveBackupManager
from src.folder_manager import FolderManager
from src.config import config  # 상수로 가져오기!
import logging
import warnings
from googleapiclient.discovery import logger as googleapiclient_logger

# 구글 API 클라이언트의 불필요한 경고 메시지 숨기기
googleapiclient_logger.setLevel(logging.ERROR)

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f"logs/memory_vault.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("MemoryVault")

def main():
    try:
        # 백업 매니저 초기화
        manager = DriveBackupManager(config.CREDENTIALS_PATH)
        
        # 인증 및 백업 실행
        manager.authenticate()
        file_id = manager.backup_memory_file(config.MEMORY_SOURCE_PATH, config.DRIVE_FOLDER_NAME)
        
        logger.info(f"Backup completed successfully. File ID: {file_id}")
        
    except Exception as e:
        logger.error(f"Backup failed: {str(e)}")
        raise
    
if __name__ == "__main__":
    main()